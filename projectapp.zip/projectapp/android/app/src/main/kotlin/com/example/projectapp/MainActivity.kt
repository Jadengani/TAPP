package com.example.projectapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
