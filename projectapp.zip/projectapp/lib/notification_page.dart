import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'notification_memory.dart';
import 'theme_provider.dart';

class NotificationPage extends StatefulWidget {
  const NotificationPage({super.key});

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  List<Map<String, dynamic>> notifications = [];

  @override
  void initState() {
    super.initState();
    _loadNotifications();
  }

  void _loadNotifications() {
    notifications = NotificationMemory.getNotifications()
        .where((n) => n['timestamp'] is DateTime)
        .toList()
        ..sort((a, b) => (b['timestamp'] as DateTime).compareTo(a['timestamp'] as DateTime));
    setState(() {});
  }

  void _clearNotifications() {
    NotificationMemory.clearNotifications();
    _loadNotifications();
  }

  IconData _getNotificationIcon(String? type) {
    switch (type) {
      case 'added':
        return Icons.add_box_rounded;
      case 'deleted':
        return Icons.delete_forever_rounded;
      case 'alert':
        return Icons.warning_rounded;
      case 'device_added':
        return Icons.devices_other_rounded;
      case 'device_deleted':
        return Icons.delete_sweep_rounded;
      case 'turned_on':
        return Icons.power_settings_new_rounded;
      case 'turned_off':
        return Icons.power_off_rounded;
      default:
        return Icons.notifications_active_rounded;
    }
  }

  String _formatTimestamp(DateTime? timestamp) {
    if (timestamp == null) return '';

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = DateTime(now.year, now.month, now.day - 1);
    final notificationDate = DateTime(timestamp.year, timestamp.month, timestamp.day);

    if (notificationDate.isAtSameMomentAs(today)) {
      return 'Today at ${DateFormat.jm().format(timestamp)}';
    } else if (notificationDate.isAtSameMomentAs(yesterday)) {
      return 'Yesterday at ${DateFormat.jm().format(timestamp)}';
    } else {
      return DateFormat('MMM d, yyyy h:mm a').format(timestamp);
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final Color primaryColor = themeProvider.primaryColor;
    final Color bgColor = themeProvider.isDarkMode ? const Color(0xFF1A1A1A) : const Color(0xFFF0F2F5);
    final Color cardColor = themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;
    final Color textColor = themeProvider.isDarkMode ? Colors.white : Colors.black87;
    final Color subtitleColor = themeProvider.isDarkMode ? Colors.grey[400]! : Colors.black54;

    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.white,
          size: 28,
        ),
        title: const Text(
          'Notifications',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontSize: 22,
          ),
        ),
        backgroundColor: primaryColor,
        elevation: 10,
        shadowColor: Colors.black87,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(6),
          ),
        ),
        actions: [
          if (notifications.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_forever_rounded),
              tooltip: "Clear All",
              color: Colors.white,
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    backgroundColor: cardColor,
                    title: Text("Clear All Notifications?", style: TextStyle(color: textColor)),
                    content: Text("This action cannot be undone.", style: TextStyle(color: subtitleColor)),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: Text("Cancel", style: TextStyle(color: subtitleColor)),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(ctx);
                          _clearNotifications();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: primaryColor,
                          foregroundColor: themeProvider.getOnPrimaryColorText(),
                        ),
                        child: const Text("Clear"),
                      ),
                    ],
                  ),
                );
              },
            )
        ],
      ),
      backgroundColor: bgColor,
      body: notifications.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.notifications_off_rounded,
                    size: 80,
                    color: subtitleColor.withOpacity(0.5),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    "No notifications yet.",
                    style: TextStyle(color: subtitleColor, fontSize: 18, fontStyle: FontStyle.italic),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    "Check back later for updates!",
                    style: TextStyle(color: subtitleColor, fontSize: 14),
                  ),
                ],
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(12),
              itemCount: notifications.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final notif = notifications[index];
                final title = notif['title'] ?? 'Notification';
                final subtitle = notif['subtitle'] ?? '';
                final timestamp = notif['timestamp'] as DateTime?;
                final type = notif['type'] as String?;

                return Card(
                  color: cardColor,
                  elevation: 6,
                  shadowColor: Colors.black.withOpacity(0.6),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  margin: EdgeInsets.zero,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(_getNotificationIcon(type), color: primaryColor, size: 28),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    title,
                                    style: TextStyle(
                                      color: textColor,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  Text(
                                    _formatTimestamp(timestamp),
                                    style: TextStyle(color: subtitleColor, fontSize: 12),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 40.0, top: 4.0),
                          child: Text(
                            subtitle,
                            style: TextStyle(color: subtitleColor, fontSize: 14),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
