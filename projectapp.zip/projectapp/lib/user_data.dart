import 'package:flutter/material.dart'; // For ChangeNotifier
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert'; // For JSON encoding/decoding
import 'package:flutter/foundation.dart'; // For debugPrint

/// Represents the user's profile information.
/// This class is immutable, and updates are handled via `copyWith`.
class UserInfo {
  final String name;
  final String email;
  final String phone;
  final String location;
  final String dob;
  final String bio;

  UserInfo({
    this.name = 'User Name',
    this.email = 'user@example.com',
    this.phone = 'N/A',
    this.location = 'N/A',
    this.dob = 'N/A',
    this.bio = 'No bio provided.',
  });

  /// Converts a UserInfo object into a JSON-serializable Map.
  Map<String, dynamic> toJson() => {
        'name': name,
        'email': email,
        'phone': phone,
        'location': location,
        'dob': dob,
        'bio': bio,
      };

  /// Creates a UserInfo object from a JSON Map.
  /// Provides default values if fields are missing.
  factory UserInfo.fromJson(Map<String, dynamic> json) {
    return UserInfo(
      name: json['name'] ?? 'User Name',
      email: json['email'] ?? 'user@example.com',
      phone: json['phone'] ?? 'N/A',
      location: json['location'] ?? 'N/A',
      dob: json['dob'] ?? 'N/A',
      bio: json['bio'] ?? 'No bio provided.',
    );
  }

  /// Creates a new UserInfo instance with updated values.
  /// Allows for partial updates without recreating the entire object.
  UserInfo copyWith({
    String? name,
    String? email,
    String? phone,
    String? location,
    String? dob,
    String? bio,
  }) {
    return UserInfo(
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      location: location ?? this.location,
      dob: dob ?? this.dob,
      bio: bio ?? this.bio,
    );
  }
}

/// Manages the UserInfo state and persists it using SharedPreferences.
/// Notifies listeners (widgets) when the user information changes.
class UserDataProvider extends ChangeNotifier {
  UserInfo _userInfo = UserInfo(
    // Initial default user data, can be overwritten by loaded data
    name: "Guest User", // Changed default to "Guest User"
    email: "guest@example.com",
    phone: "N/A",
    location: "Unknown",
    dob: "N/A",
    bio: "Welcome to Tapp!",
  );
  static const String _userInfoKey = 'user_info';

  UserDataProvider() {
    _loadUserInfo(); // Load user info when the provider is created
  }

  /// Getter to access the current user information.
  UserInfo get userInfo => _userInfo;

  /// Loads user information from SharedPreferences.
  Future<void> _loadUserInfo() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? userInfoString = prefs.getString(_userInfoKey);
      if (userInfoString != null) {
        _userInfo = UserInfo.fromJson(jsonDecode(userInfoString));
        notifyListeners(); // Notify widgets after loading
      }
    } catch (e) {
      debugPrint('Error loading user info: $e');
      // Optionally reset to default or handle error gracefully
      _userInfo = UserInfo();
      notifyListeners();
    }
  }

  /// Updates user information and saves it to SharedPreferences.
  Future<void> updateUserInfo({
    String? name,
    String? email,
    String? phone,
    String? location,
    String? dob,
    String? bio,
  }) async {
    _userInfo = _userInfo.copyWith(
      name: name,
      email: email,
      phone: phone,
      location: location,
      dob: dob,
      bio: bio,
    );

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_userInfoKey, jsonEncode(_userInfo.toJson()));
      notifyListeners(); // Notify widgets after updating and saving
    } catch (e) {
      debugPrint('Error saving user info: $e');
    }
  }

  /// Clears user information from SharedPreferences and resets to default.
  Future<void> clearUserInfo() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_userInfoKey);
      _userInfo = UserInfo(); // Reset to default
      notifyListeners(); // Notify widgets after clearing
    } catch (e) {
      debugPrint('Error clearing user info: $e');
    }
  }
}
