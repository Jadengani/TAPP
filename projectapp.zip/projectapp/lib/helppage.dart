import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';

class HelpPage extends StatelessWidget {

  const HelpPage({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final Color bgColor = themeProvider.isDarkMode ? const Color(0xFF1A1A1A) : const Color(0xFFF0F2F5);
    final Color textColor = themeProvider.isDarkMode ? Colors.white : Colors.black87;
    final Color subtitleColor = themeProvider.isDarkMode ? Colors.grey[400]! : Colors.black54;
    final Color cardColor = themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;
    final Color primaryColor = themeProvider.primaryColor;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.white,
          size: 28,
        ),
        title: const Text(
          'Help & Support',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontSize: 22,
          ),
        ),
        backgroundColor: primaryColor,
        elevation: 10,
        shadowColor: Colors.black87,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(6),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Frequently Asked Questions (FAQ)',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: textColor,
              ),
            ),
            const SizedBox(height: 20),
            _buildFAQItem(
              question: 'How do I add a new room?',
              answer: 'On the home screen, tap the "Room:" dropdown and select "Add". Choose a room type from the list and confirm. A new room will appear in your grid.',
              textColor: textColor,
              subtitleColor: subtitleColor,
              cardColor: cardColor,
              primaryColor: primaryColor,
            ),
            _buildFAQItem(
              question: 'How do I control devices in a room?',
              answer: 'From the home screen, tap on the desired room card. This will take you to the remote control page for that room, where you can adjust lights, fans, AC, etc.',
              textColor: textColor,
              subtitleColor: subtitleColor,
              cardColor: cardColor,
              primaryColor: primaryColor,
            ),
            _buildFAQItem(
              question: 'Where can I see my notifications?',
              answer: 'Notifications are accessible via the "Notifications" icon in the bottom navigation bar on the home screen, or from the drawer menu.',
              textColor: textColor,
              subtitleColor: subtitleColor,
              cardColor: cardColor,
              primaryColor: primaryColor,
            ),
            _buildFAQItem(
              question: 'How do I change my profile information?',
              answer: 'You can update your profile by tapping your name or the user icon in the top right corner of the home screen, or by selecting "User Profile" from the settings page.',
              textColor: textColor,
              subtitleColor: subtitleColor,
              cardColor: cardColor,
              primaryColor: primaryColor,
            ),
            _buildFAQItem(
              question: 'How do I switch between dark and light mode?',
              answer: 'You can toggle the theme from the sun/moon icon in the app bar on the home page, or find a theme setting option within the "Settings" page.',
              textColor: textColor,
              subtitleColor: subtitleColor,
              cardColor: cardColor,
              primaryColor: primaryColor,
            ),
            const SizedBox(height: 30),
            Text(
              'Contact Support',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: textColor,
              ),
            ),
            const SizedBox(height: 10),
            _buildContactInfo(
              icon: Icons.email,
              text: 'Email: support@tapp.com',
              textColor: textColor,
              subtitleColor: subtitleColor,
              cardColor: cardColor,
            ),
            _buildContactInfo(
              icon: Icons.phone,
              text: 'Phone: +1 (555) 123-4567',
              textColor: textColor,
              subtitleColor: subtitleColor,
              cardColor: cardColor,
            ),
            _buildContactInfo(
              icon: Icons.web,
              text: 'Website: www.tapp.com',
              textColor: textColor,
              subtitleColor: subtitleColor,
              cardColor: cardColor,
            ),
            const SizedBox(height: 20),
            Center(
              child: Text(
                '© 2024 Tapp Home Automation. All rights reserved.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: subtitleColor),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFAQItem({
    required String question,
    required String answer,
    required Color textColor,
    required Color subtitleColor,
    required Color cardColor,
    required Color primaryColor,
  }) {
    return Card(
      color: cardColor,
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        leading: Icon(Icons.help_outline, color: primaryColor),
        title: Text(
          question,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: textColor,
          ),
        ),
        collapsedIconColor: subtitleColor,
        iconColor: primaryColor,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(16.0, 0.0, 16.0, 16.0),
            child: Text(
              answer,
              style: TextStyle(fontSize: 14, color: subtitleColor),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactInfo({
    required IconData icon,
    required String text,
    required Color textColor,
    required Color subtitleColor,
    required Color cardColor,
  }) {
    return Card(
      color: cardColor,
      margin: const EdgeInsets.symmetric(vertical: 6.0),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          children: [
            Icon(icon, color: textColor.withOpacity(0.7), size: 24),
            const SizedBox(width: 12),
            Text(
              text,
              style: TextStyle(fontSize: 16, color: textColor),
            ),
          ],
        ),
      ),
    );
  }
}
