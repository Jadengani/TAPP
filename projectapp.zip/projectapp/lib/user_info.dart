// lib/user_data.dart
import 'package:flutter/foundation.dart'; // For ChangeNotifier

// UserInfo class (copy this directly from your provided code)
class UserInfo {
  final String name;
  final String email;
  final String phone;
  final String location;
  final String dob;
  final String bio;

  UserInfo({
    required this.name,
    required this.email,
    required this.phone,
    required this.location,
    required this.dob,
    required this.bio,
  });

  UserInfo copyWith({
    String? name,
    String? email,
    String? phone,
    String? location,
    String? dob,
    String? bio,
  }) {
    return UserInfo(
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      location: location ?? this.location,
      dob: dob ?? this.dob,
      bio: bio ?? this.bio,
    );
  }
}

// UserDataProvider class to manage UserInfo and notify listeners
class UserDataProvider with ChangeNotifier {
  // Initial user data
  UserInfo _userInfo = UserInfo(
    name: "John Doe",
    email: "johndoe@example.com",
    phone: "09123456789",
    location: "Lipa City, Calabarzon, Philippines", // Using current location
    dob: "January 1, 1990",
    bio: "Hello! I’m using this app.",
  );

  // Getter to access the current user info
  UserInfo get userInfo => _userInfo;

  // Method to update user info
  void updateUserInfo({
    String? name,
    String? email,
    String? phone,
    String? location,
    String? dob,
    String? bio,
  }) {
    _userInfo = _userInfo.copyWith(
      name: name,
      email: email,
      phone: phone,
      location: location,
      dob: dob,
      bio: bio,
    );
    notifyListeners(); // Notify all widgets listening to this provider
  }
}