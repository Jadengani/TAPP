import 'package:flutter/foundation.dart';

class UserInfo {
  final String name;
  final String email;
  final String phone;
  final String location;
  final String dob;
  final String bio;

  UserInfo({
    required this.name,
    required this.email,
    required this.phone,
    required this.location,
    required this.dob,
    required this.bio,
  });

  UserInfo copyWith({
    String? name,
    String? email,
    String? phone,
    String? location,
    String? dob,
    String? bio,
  }) {
    return UserInfo(
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      location: location ?? this.location,
      dob: dob ?? this.dob,
      bio: bio ?? this.bio,
    );
  }
}

class UserDataProvider with ChangeNotifier {
  // Initial user data
  UserInfo _userInfo = UserInfo(
    name: "John Doe",
    email: "johndoe@example.com",
    phone: "09123456789",
    location: "Lipa City, Calabarzon, Philippines",
    dob: "January 1, 1990",
    bio: "Hello! I’m using this app.",
  );

  UserInfo get userInfo => _userInfo;

  void updateUserInfo({
    String? name,
    String? email,
    String? phone,
    String? location,
    String? dob,
    String? bio,
  }) {
    _userInfo = _userInfo.copyWith(
      name: name,
      email: email,
      phone: phone,
      location: location,
      dob: dob,
      bio: bio,
    );
    notifyListeners();
  }
}