import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:flutter/foundation.dart'; // <--- This import is crucial for debugPrint

class NotificationMemory {
  static const String _notificationsKey = 'app_notifications';

  static List<Map<String, dynamic>> _notifications = [];
  static bool _isLoaded = false;

  // Private constructor for singleton pattern
  NotificationMemory._privateConstructor();

  // Singleton instance
  static final NotificationMemory _instance = NotificationMemory._privateConstructor();

  // Factory constructor to return the same instance
  factory NotificationMemory() {
    return _instance;
  }

  // Public static method to load notifications, ensuring it's only loaded once
  static Future<void> loadNotifications() async {
    if (_isLoaded) return; // Prevent re-loading if already loaded

    try {
      final prefs = await SharedPreferences.getInstance();
      final String? notificationsString = prefs.getString(_notificationsKey);
      if (notificationsString != null) {
        final List<dynamic> decodedList = jsonDecode(notificationsString);
        _notifications = decodedList.map((item) {
          // Ensure timestamp is parsed correctly
          if (item['timestamp'] != null && item['timestamp'] is String) {
            try {
              item['timestamp'] = DateTime.parse(item['timestamp']);
            } catch (e) {
              // Fallback if parsing fails
              item['timestamp'] = DateTime.now();
              debugPrint('Error parsing timestamp: $e'); // debugPrint should now be available
            }
          } else if (item['timestamp'] == null) {
            item['timestamp'] = DateTime.now(); // Assign current time if null
          }
          return item as Map<String, dynamic>;
        }).toList();
      } else {
        _notifications = [];
      }
      _isLoaded = true;
    } catch (e) {
      debugPrint('Error loading notifications: $e'); // debugPrint should now be available
      _notifications = []; // Ensure notifications is empty on error
      _isLoaded = true; // Mark as loaded to prevent continuous attempts
    }
  }

  // Private static method to save notifications
  static Future<void> _saveNotifications() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final List<Map<String, dynamic>> encodableNotifications = _notifications.map((notif) {
        final Map<String, dynamic> newNotif = Map.from(notif);
        if (newNotif['timestamp'] is DateTime) {
          newNotif['timestamp'] = (newNotif['timestamp'] as DateTime).toIso8601String();
        }
        return newNotif;
      }).toList();
      await prefs.setString(_notificationsKey, jsonEncode(encodableNotifications));
    } catch (e) {
      debugPrint('Error saving notifications: $e'); // debugPrint should now be available
    }
  }

  // Returns a copy of the notifications list to prevent external modification
  static List<Map<String, dynamic>> getNotifications() {
    if (!_isLoaded) {
      loadNotifications(); // Fire and forget if not loaded, will load asynchronously
    }
    return List.from(_notifications);
  }

  static void addNotification(Map<String, dynamic> notification) {
    if (!_isLoaded) {
      loadNotifications().then((_) {
        _addAndSave(notification);
      });
    } else {
      _addAndSave(notification);
    }
  }

  // Helper to add and save, ensuring timestamp is handled
  static void _addAndSave(Map<String, dynamic> notification) {
    if (notification['timestamp'] == null) {
      notification['timestamp'] = DateTime.now();
    } else if (notification['timestamp'] is! DateTime) {
      try {
        notification['timestamp'] = DateTime.parse(notification['timestamp'].toString());
      } catch (_) {
        notification['timestamp'] = DateTime.now();
      }
    }

    _notifications.add(notification);
    _saveNotifications();
  }

  static void clearNotifications() {
    _notifications.clear();
    _saveNotifications();
  }
}
