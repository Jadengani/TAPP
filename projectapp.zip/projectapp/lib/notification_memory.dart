import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:flutter/foundation.dart';

class NotificationMemory {
  static const String _notificationsKey = 'app_notifications';

  static List<Map<String, dynamic>> _notifications = [];
  static bool _isLoaded = false;

  NotificationMemory._privateConstructor();

  static final NotificationMemory _instance = NotificationMemory._privateConstructor();

  factory NotificationMemory() {
    return _instance;
  }

  static Future<void> loadNotifications() async {
    if (_isLoaded) return;

    try {
      final prefs = await SharedPreferences.getInstance();
      final String? notificationsString = prefs.getString(_notificationsKey);
      if (notificationsString != null) {
        final List<dynamic> decodedList = jsonDecode(notificationsString);
        _notifications = decodedList.map((item) {
          if (item['timestamp'] != null && item['timestamp'] is String) {
            try {
              item['timestamp'] = DateTime.parse(item['timestamp']);
            } catch (e) {
              item['timestamp'] = DateTime.now();
              debugPrint('Error parsing timestamp: $e');
            }
          } else if (item['timestamp'] == null) {
            item['timestamp'] = DateTime.now();
          }
          return item as Map<String, dynamic>;
        }).toList();
      } else {
        _notifications = [];
      }
      _isLoaded = true;
    } catch (e) {
      debugPrint('Error loading notifications: $e');
      _notifications = [];
      _isLoaded = true;
    }
  }

  static Future<void> _saveNotifications() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final List<Map<String, dynamic>> encodableNotifications = _notifications.map((notif) {
        final Map<String, dynamic> newNotif = Map.from(notif);
        if (newNotif['timestamp'] is DateTime) {
          newNotif['timestamp'] = (newNotif['timestamp'] as DateTime).toIso8601String();
        }
        return newNotif;
      }).toList();
      await prefs.setString(_notificationsKey, jsonEncode(encodableNotifications));
    } catch (e) {
      debugPrint('Error saving notifications: $e');
    }
  }


  static List<Map<String, dynamic>> getNotifications() {
    if (!_isLoaded) {
      loadNotifications();
    }
    return List.from(_notifications);
  }

  static void addNotification(Map<String, dynamic> notification) {
    if (!_isLoaded) {
      loadNotifications().then((_) {
        _addAndSave(notification);
      });
    } else {
      _addAndSave(notification);
    }
  }

  static void _addAndSave(Map<String, dynamic> notification) {
    if (notification['timestamp'] == null) {
      notification['timestamp'] = DateTime.now();
    } else if (notification['timestamp'] is! DateTime) {
      try {
        notification['timestamp'] = DateTime.parse(notification['timestamp'].toString());
      } catch (_) {
        notification['timestamp'] = DateTime.now();
      }
    }

    _notifications.add(notification);
    _saveNotifications();
  }

  static void clearNotifications() {
    _notifications.clear();
    _saveNotifications();
  }
}
