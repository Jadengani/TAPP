import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:provider/provider.dart';
import 'notification_memory.dart';
import 'theme_provider.dart';

class RemotePage extends StatefulWidget {
  final String roomName;
  const RemotePage({
    super.key,
    required this.roomName,
  });

  @override
  State<RemotePage> createState() => _RemotePageState();
}

class _RemotePageState extends State<RemotePage> {
  static final Map<String, List<String>> _roomDevices = {};
  static final Map<String, Map<String, bool>> _roomDeviceStates = {};

  List<String> get devices => _roomDevices[widget.roomName] ??= [];
  Map<String, bool> get deviceStates => _roomDeviceStates[widget.roomName] ??= {};

  final List<String> allDevices = [
    'Light', 'Speaker', 'Outlet', 'Television', 'CCTV',
    'Aircon', 'Refrigerator', 'PC', 'Heater', 'Fan',
  ];

  final Map<String, IconData> deviceIcons = {
    'Light': Icons.lightbulb,
    'Speaker': Icons.speaker,
    'Outlet': Icons.power_outlined,
    'Television': Icons.tv,
    'CCTV': Icons.videocam,
    'Aircon': Icons.ac_unit,
    'Refrigerator': Icons.kitchen,
    'PC': Icons.computer,
    'Heater': Icons.whatshot,
    'Fan': Icons.toys,
  };

  String? filterDevice;

  void _addDevice(String deviceName) {
    setState(() {
      int count = devices.where((d) => d.startsWith(deviceName)).length;
      String newName = count == 0 ? deviceName : '$deviceName ${count + 1}';

      devices.add(newName);
      deviceStates[newName] = false; 
      filterDevice = null;

      NotificationMemory.addNotification({
        'type': 'device_added',
        'title': 'Device Added',
        'subtitle': '$newName added in ${widget.roomName}',
        'timestamp': DateTime.now(),
      });
    });
  }

  void _toggleDevice(String deviceName, bool newValue) {
    setState(() {
      deviceStates[deviceName] = newValue;

      NotificationMemory.addNotification({
        'type': newValue ? 'turned_on' : 'turned_off',
        'title': 'Device ${newValue ? 'Turned On' : 'Turned Off'}',
        'subtitle': '$deviceName ${newValue ? 'on' : 'off'} in ${widget.roomName}',
        'timestamp': DateTime.now(),
      });
    });
  }

  void _removeDevice(String deviceName) {
    setState(() {
      devices.remove(deviceName);
      deviceStates.remove(deviceName);
      if (filterDevice == deviceName) filterDevice = null;

      NotificationMemory.addNotification({
        'type': 'device_deleted',
        'title': 'Device Deleted',
        'subtitle': '$deviceName removed from ${widget.roomName}',
        'timestamp': DateTime.now(),
      });
    });
  }

  IconData _getIconForDevice(String deviceName) {
    String baseName = deviceName.split(' ')[0];
    return deviceIcons[baseName] ?? Icons.device_unknown;
  }

  void _showAddDeviceDialog() {
    final themeProvider = Provider.of<ThemeProvider>(context, listen: false);
    final dialogBgColor = themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;
    final dialogTextColor = themeProvider.isDarkMode ? Colors.white : Colors.black87;
    final primaryColor = themeProvider.primaryColor;

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: dialogBgColor,
          title: Text('Add Device', style: TextStyle(color: dialogTextColor, fontWeight: FontWeight.bold)),
          content: SizedBox(
            width: double.maxFinite,
            height: 300,
            child: ListView.builder(
              itemCount: allDevices.length,
              itemBuilder: (context, index) {
                final device = allDevices[index];
                return ListTile(
                  leading: Icon(deviceIcons[device] ?? Icons.device_unknown, color: primaryColor),
                  title: Text(device, style: TextStyle(color: dialogTextColor)),
                  onTap: () {
                    Navigator.of(context).pop();
                    _addDevice(device);
                  },
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel', style: TextStyle(color: primaryColor)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final Color primaryColor = themeProvider.primaryColor;
    final Color bgColor = themeProvider.isDarkMode ? const Color(0xFF1A1A1A) : const Color(0xFFF0F2F5);
    final Color textColor = themeProvider.isDarkMode ? Colors.white : Colors.black87;
    final Color cardColor = themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;
    final filteredDevices = filterDevice == null
        ? devices
        : devices.where((d) => d.startsWith(filterDevice!)).toList();

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          '${widget.roomName} Remote',
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w900,
            color: Colors.white,
          ),
        ),
        backgroundColor: primaryColor,
        elevation: 10,
        shadowColor: Colors.black87,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(6)),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(
                top: MediaQuery.of(context).size.height * 0.05,
                left: MediaQuery.of(context).size.width * 0.03,
                bottom: 16,
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.wb_sunny, size: 60, color: primaryColor),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Sunny',
                        style: TextStyle(
                          fontSize: 50,
                          color: textColor,
                          fontWeight: FontWeight.bold,
                          height: 1.0,
                        ),
                      ),
                      Text(
                        '25°C',
                        style: TextStyle(
                          fontSize: 20,
                          color: textColor,
                          fontWeight: FontWeight.w600,
                          height: 1.0,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Your Devices',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      color: textColor,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: _showAddDeviceDialog,
                        child: CircleAvatar(
                          backgroundColor: primaryColor,
                          radius: 18,
                          child: const Icon(Icons.add, color: Colors.white),
                        ),
                      ),
                      const SizedBox(width: 16),
                      GestureDetector(
                        onTap: () => setState(() => filterDevice = null),
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: filterDevice == null
                                ? primaryColor
                                : (themeProvider.isDarkMode ? Colors.grey[700] : Colors.grey.shade300),
                          ),
                          child: Icon(
                            Icons.devices,
                            color: filterDevice == null
                                ? Colors.white
                                : (themeProvider.isDarkMode ? Colors.white70 : Colors.black54),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: SizedBox(
                          height: 44,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              ...{
                                for (var d in devices) d.split(' ')[0]
                              }.map((deviceName) {
                                return GestureDetector(
                                  onTap: () => setState(() {
                                    filterDevice = deviceName;
                                  }),
                                  child: Container(
                                    margin: const EdgeInsets.only(right: 8),
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: filterDevice == deviceName
                                          ? primaryColor // Active filter uses primary color
                                          : (themeProvider.isDarkMode ? Colors.grey[700] : Colors.grey.shade300),
                                    ),
                                    child: Icon(
                                      deviceIcons[deviceName] ?? Icons.device_unknown,
                                      color: filterDevice == deviceName
                                          ? Colors.white
                                          : (themeProvider.isDarkMode ? Colors.white70 : Colors.black54),
                                    ),
                                  ),
                                );
                              }),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 10),

            Expanded(
              child: filteredDevices.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.device_hub_outlined, size: 80, color: textColor.withOpacity(0.5)),
                          const SizedBox(height: 20),
                          Text("No devices added yet or matching filter.", style: TextStyle(color: textColor.withOpacity(0.7), fontSize: 16, fontStyle: FontStyle.italic)),
                          const SizedBox(height: 5),
                          Text("Tap '+' to add a device!", style: TextStyle(color: textColor.withOpacity(0.6), fontSize: 14)),
                        ],
                      ),
                    )
                  : MasonryGridView.count(
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      itemCount: filteredDevices.length,
                      itemBuilder: (context, index) {
                        final deviceName = filteredDevices[index];
                        final icon = _getIconForDevice(deviceName);
                        final isOn = deviceStates[deviceName] ?? false;
                        final double height = 120 + (index % 3) * 20;

                        return GestureDetector(
                          onLongPress: () {
                            showDialog(
                              context: context,
                              builder: (_) => AlertDialog(
                                backgroundColor: cardColor,
                                title: Text('Delete Device?', style: TextStyle(color: textColor)),
                                content: Text('Remove $deviceName?', style: TextStyle(color: textColor.withOpacity(0.8))),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(context),
                                    child: Text('Cancel', style: TextStyle(color: primaryColor)),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      _removeDevice(deviceName);
                                      Navigator.pop(context);
                                    },
                                    child: const Text(
                                      'Delete',
                                      style: TextStyle(color: Colors.red),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                          child: Container(
                            height: height,
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: isOn ? primaryColor : (themeProvider.isDarkMode ? Colors.grey[700] : Colors.grey.shade200),
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: themeProvider.isDarkMode ? Colors.black.withOpacity(0.6) : Colors.grey.withOpacity(0.4),
                                  blurRadius: 10,
                                  offset: const Offset(0, 5),
                                ),
                              ],
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  top: 0,
                                  left: 0,
                                  child: Icon(icon, size: 40, color: isOn ? themeProvider.getOnPrimaryColorText() : textColor.withOpacity(0.8)),
                                ),
                                Positioned(
                                  bottom: 0,
                                  left: 0,
                                  right: 0,
                                  child: Text(
                                    deviceName,
                                    style: TextStyle(
                                      color: isOn ? themeProvider.getOnPrimaryColorText() : textColor,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                      shadows: [
                                        Shadow(
                                          color: Colors.black.withOpacity(isOn ? 0.4 : 0.2),
                                          blurRadius: 2,
                                          offset: const Offset(1, 1),
                                        ),
                                      ],
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                Positioned(
                                  top: 4,
                                  right: 4,
                                  child: Transform.scale(
                                    scale: 0.7,
                                    child: Switch(
                                      value: isOn,
                                      onChanged: (val) => _toggleDevice(deviceName, val),
                                      activeColor: themeProvider.getOnPrimaryColorText(), // Switch active color
                                      inactiveThumbColor: themeProvider.isDarkMode ? Colors.grey[400] : Colors.white54, // Switch inactive thumb color
                                      inactiveTrackColor: themeProvider.isDarkMode ? Colors.grey[600] : Colors.white30, // Switch inactive track color
                                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
