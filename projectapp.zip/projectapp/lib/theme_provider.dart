import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeProvider with ChangeNotifier {
  static const String _darkModeKey = 'is_dark_mode';
  static const String _primaryColorKey = 'primary_color_value';

  bool _isDarkMode = false;
  Color _primaryColor = const Color(0xFF77BEF0); // Default primary color

  // Predefined pastel colors for the user to choose from
  final List<Color> pastelColors = [
    const Color(0xFF77BEF0), // Your current blue
    const Color(0xFFB6E2D3), // Light Teal
    const Color(0xFFFAE3D9), // Light Peach
    const Color(0xFFFFC7B2), // Soft Orange
    const Color(0xFFD4A5A5), // Dusty Rose
    const Color(0xFFC9F0EE), // Pale Cyan
    const Color(0xFFF0F2F5), // Light Grey (almost white, good for light themes)
  ];

  ThemeProvider() {
    _loadThemePreferences();
  }

  bool get isDarkMode => _isDarkMode;
  Color get primaryColor => _primaryColor;

  Future<void> _loadThemePreferences() async {
    final prefs = await SharedPreferences.getInstance();
    _isDarkMode = prefs.getBool(_darkModeKey) ?? false;
    final int? colorValue = prefs.getInt(_primaryColorKey);
    if (colorValue != null) {
      _primaryColor = Color(colorValue);
    }
    notifyListeners();
  }

  Future<void> toggleTheme() async {
    _isDarkMode = !_isDarkMode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_darkModeKey, _isDarkMode);
    notifyListeners();
  }

  Future<void> setPrimaryColor(Color color) async {
    _primaryColor = color;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_primaryColorKey, color.value);
    notifyListeners();
  }

  // Helper to get text color based on primary color brightness
  Color getOnPrimaryColorText() {
    // Determine if the primary color is light or dark
    // and return contrasting text color for better readability on buttons etc.
    return _primaryColor.computeLuminance() > 0.5 ? Colors.black87 : Colors.white;
  }
}