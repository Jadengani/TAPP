import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeProvider with ChangeNotifier {
  static const String _darkModeKey = 'is_dark_mode';
  static const String _primaryColorKey = 'primary_color_value';

  bool _isDarkMode = false;
  Color _primaryColor = const Color(0xFF77BEF0);

  final List<Color> pastelColors = [
    const Color(0xFF77BEF0),
    const Color(0xFFB6E2D3),
    const Color(0xFFFAE3D9),
    const Color(0xFFFFC7B2),
    const Color(0xFFD4A5A5),
    const Color(0xFFC9F0EE),
    const Color(0xFFF0F2F5),
  ];

  ThemeProvider() {
    _loadThemePreferences();
  }

  bool get isDarkMode => _isDarkMode;
  Color get primaryColor => _primaryColor;

  Future<void> _loadThemePreferences() async {
    final prefs = await SharedPreferences.getInstance();
    _isDarkMode = prefs.getBool(_darkModeKey) ?? false;
    final int? colorValue = prefs.getInt(_primaryColorKey);
    if (colorValue != null) {
      _primaryColor = Color(colorValue);
    }
    notifyListeners();
  }

  Future<void> toggleTheme() async {
    _isDarkMode = !_isDarkMode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_darkModeKey, _isDarkMode);
    notifyListeners();
  }

  Future<void> setPrimaryColor(Color color) async {
    _primaryColor = color;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_primaryColorKey, color.value);
    notifyListeners();
  }

  Color getOnPrimaryColorText() {
    return _primaryColor.computeLuminance() > 0.5 ? Colors.black87 : Colors.white;
  }
}