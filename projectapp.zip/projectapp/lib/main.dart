import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'loginpage.dart';
import 'user_data.dart';
import 'theme_provider.dart';
import 'splash_screen.dart';

void showMessageBox(BuildContext context, String title, String message) {
  final themeProvider = Provider.of<ThemeProvider>(context, listen: false);
  final bool isDarkMode = themeProvider.isDarkMode;
  final Color dialogBgColor = isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;
  final Color dialogTextColor = isDarkMode ? Colors.white : Colors.black87;
  final Color primaryColor = themeProvider.primaryColor;

  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        backgroundColor: dialogBgColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
        title: Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: dialogTextColor)),
        content: Text(message, style: TextStyle(color: dialogTextColor)),
        actions: <Widget>[
          TextButton(
            child: Text('OK', style: TextStyle(color: primaryColor)),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ],
      );
    },
  );
}

void main() {

  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => UserDataProvider()),
        ChangeNotifierProvider(create: (context) => ThemeProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return MaterialApp(
      title: 'TAPP',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Inter',
        primaryColor: themeProvider.primaryColor,
        colorScheme: ColorScheme.light(
          primary: themeProvider.primaryColor,
          onPrimary: themeProvider.getOnPrimaryColorText(),
          secondary: themeProvider.primaryColor.withOpacity(0.8),
          onSecondary: themeProvider.getOnPrimaryColorText(),
          surface: const Color(0xFFF0F2F5),
          onSurface: Colors.black87,
          background: const Color(0xFFF0F2F5),
          onBackground: Colors.black87,
          error: Colors.red,
          onError: Colors.white,
          brightness: Brightness.light,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: themeProvider.primaryColor,
          foregroundColor: Colors.white,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: themeProvider.primaryColor,
            foregroundColor: themeProvider.getOnPrimaryColorText(),
          ),
        ),
        textButtonTheme: TextButtonThemeData(
            style: TextButton.styleFrom(foregroundColor: themeProvider.primaryColor),
        ),
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      darkTheme: ThemeData(
        fontFamily: 'Inter',
        brightness: Brightness.dark,
        primaryColor: themeProvider.primaryColor,
        colorScheme: ColorScheme.dark(
          primary: themeProvider.primaryColor,
          onPrimary: themeProvider.getOnPrimaryColorText(),
          secondary: themeProvider.primaryColor.withOpacity(0.8),
          onSecondary: themeProvider.getOnPrimaryColorText(),
          surface: const Color(0xFF2C2C2C),
          onSurface: Colors.white,
          background: const Color(0xFF1A1A1A),
          onBackground: Colors.white,
          error: Colors.redAccent,
          onError: Colors.white,
          brightness: Brightness.dark,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: themeProvider.primaryColor,
          foregroundColor: Colors.white,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: themeProvider.primaryColor,
            foregroundColor: themeProvider.getOnPrimaryColorText(),
          ),
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(foregroundColor: themeProvider.primaryColor),
        ),
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      themeMode: themeProvider.isDarkMode ? ThemeMode.dark : ThemeMode.light,
      home: const SplashScreen(),
    );
  }
}
