import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'changepassword.dart';
import 'theme_provider.dart';

class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({super.key});

  @override
  State<ForgotPasswordPage> createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  final TextEditingController _codeController = TextEditingController();

  @override
  void dispose() {
    _codeController.dispose();
    super.dispose();
  }

  void _showMessageBox(BuildContext context, String title, String message, {VoidCallback? onOkPressed}) {
    final themeProvider = Provider.of<ThemeProvider>(context, listen: false);
    final bool isDarkMode = themeProvider.isDarkMode;
    final Color dialogBgColor = isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;
    final Color dialogTextColor = isDarkMode ? Colors.white : Colors.black87;
    final Color primaryColor = themeProvider.primaryColor;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: dialogBgColor,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
          title: Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: dialogTextColor)),
          content: Text(message, style: TextStyle(color: dialogTextColor)),
          actions: <Widget>[
            TextButton(
              child: Text('OK', style: TextStyle(color: primaryColor)),
              onPressed: onOkPressed ?? () => Navigator.of(context).pop(),
            ),
          ],
        );
      },
    );
  }

  void _handleSubmit() {
    String code = _codeController.text.trim();

    if (code == '12345') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ChangePasswordPage()),
      );
    } else {
      _showMessageBox(
        context,
        'Invalid Code',
        'The verification code you entered is incorrect.',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final Color bgColor = themeProvider.isDarkMode ? const Color(0xFF1A1A1A) : const Color(0xFF77BEF0);
    final Color textColor = themeProvider.isDarkMode ? Colors.white : Colors.black87;
    final Color primaryColor = themeProvider.primaryColor;
    final Color cardColor = themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;


    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: primaryColor,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            width: 360,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: themeProvider.isDarkMode ? Colors.black54 : Colors.black26,
                  blurRadius: 12,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(height: 12),
                Image.asset('assets/images/logo.png', height: 75),
                const SizedBox(height: 12),
                Text(
                  'Reset Password',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: textColor),
                ),
                const SizedBox(height: 12),
                Text(
                  'A verification code has been sent to your Email.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: textColor.withOpacity(0.7)),
                ),
                const SizedBox(height: 24),
                TextField(
                  controller: _codeController,
                  style: TextStyle(color: textColor),
                  decoration: InputDecoration(
                    hintText: 'Code',
                    hintStyle: TextStyle(color: textColor.withOpacity(0.5)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: textColor.withOpacity(0.5)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: textColor.withOpacity(0.5)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: primaryColor, width: 2),
                    ),
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _handleSubmit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primaryColor,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      foregroundColor: themeProvider.getOnPrimaryColorText(),
                    ),
                    child: const Text('Submit'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}