import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'main.dart';
import 'theme_provider.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});
  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final _usernameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  bool _isPasswordVisible = false;
  bool _isConfirmPasswordVisible = false;


  @override
  void dispose() {
    _usernameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _handleSignUp() {
    final username = _usernameController.text.trim();
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();
    final confirmPassword = _confirmPasswordController.text.trim();

    if (username.isEmpty || email.isEmpty || password.isEmpty || confirmPassword.isEmpty) {
      showMessageBox(context, 'Error', 'Please fill in all fields.');
      return;
    }

    if (password.length < 6) {
      showMessageBox(context, 'Password Too Short', 'Password must be at least 6 characters long.');
      return;
    }

    if (password != confirmPassword) {
      showMessageBox(context, 'Error', 'Passwords do not match.');
      return;
    }

    final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
    if (!emailRegex.hasMatch(email)) {
      showMessageBox(context, 'Invalid Email', 'Please enter a valid email address.');
      return;
    }

    showMessageBox(context, 'Account Created', 'Account for $username created!');
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final Color bgColor = themeProvider.isDarkMode ? const Color(0xFF1A1A1A) : const Color(0xFF77BEF0);
    final Color textColor = themeProvider.isDarkMode ? Colors.white : Colors.black87;
    final Color primaryColor = themeProvider.primaryColor;
    final Color cardColor = themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;


    return Scaffold(
      backgroundColor: bgColor,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(16.0),
              boxShadow: [
                BoxShadow(
                  color: themeProvider.isDarkMode ? Colors.black54 : Colors.black26,
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            constraints: const BoxConstraints(maxWidth: 340),
            child: Column(
              children: [
                const SizedBox(height: 12),
                Image.asset(
                  'assets/images/logo.png',
                  width: 90,
                  height: 90,
                  fit: BoxFit.contain,
                ),
                const SizedBox(height: 16),
                Text(
                  'Create Account',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: textColor),
                ),
                const SizedBox(height: 20),
                _buildField('Username', _usernameController, false, textColor, primaryColor),
                _buildField('Email Address', _emailController, false, textColor, primaryColor, keyboardType: TextInputType.emailAddress),
                _buildField('Password', _passwordController, true, textColor, primaryColor, isPasswordToggle: true, isVisible: _isPasswordVisible, onToggle: (val) => setState(() => _isPasswordVisible = val)),
                _buildField('Confirm Password', _confirmPasswordController, true, textColor, primaryColor, isPasswordToggle: true, isVisible: _isConfirmPasswordVisible, onToggle: (val) => setState(() => _isConfirmPasswordVisible = val)),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _handleSignUp,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    foregroundColor: themeProvider.getOnPrimaryColorText(),
                    minimumSize: const Size(double.infinity, 48),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Text('Create Account'),
                ),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(
                    'Already have an account? Sign in',
                    style: TextStyle(color: primaryColor),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildField(String label, TextEditingController controller, bool obscure, Color textColor, Color primaryColor, {TextInputType keyboardType = TextInputType.text, bool isPasswordToggle = false, bool isVisible = false, ValueChanged<bool>? onToggle}) {
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: TextField(
        controller: controller,
        obscureText: obscure && !isVisible,
        style: TextStyle(color: textColor),
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: textColor.withOpacity(0.7)),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: textColor.withOpacity(0.5)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: textColor.withOpacity(0.5)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: primaryColor, width: 2),
          ),
          filled: true,
          fillColor: Colors.transparent,
          suffixIcon: isPasswordToggle
              ? IconButton(
                  icon: Icon(
                    isVisible ? Icons.visibility : Icons.visibility_off,
                    color: textColor.withOpacity(0.7),
                  ),
                  onPressed: () {
                    onToggle?.call(!isVisible);
                  },
                )
              : null,
        ),
      ),
    );
  }
}
