import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'homepage.dart'; // Make sure this path matches your project structure
import 'theme_provider.dart'; // Import the new ThemeProvider

class ChangePasswordPage extends StatefulWidget {
  const ChangePasswordPage({super.key});

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final TextEditingController _newPasswordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();
  bool _isNewPasswordVisible = false; // State for new password visibility
  bool _isConfirmPasswordVisible = false; // State for confirm password visibility

  @override
  void dispose() {
    // Dispose of the controllers when the widget is removed from the tree
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  // Helper method to show AlertDialogs, now using ThemeProvider for consistent styling
  void _showMessageBox(BuildContext context, String title, String message, {VoidCallback? onOkPressed}) {
    final themeProvider = Provider.of<ThemeProvider>(context, listen: false);
    final bool isDarkMode = themeProvider.isDarkMode;
    final Color dialogBgColor = isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;
    final Color dialogTextColor = isDarkMode ? Colors.white : Colors.black87;
    final Color primaryColor = themeProvider.primaryColor;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: dialogBgColor,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
          title: Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: dialogTextColor)),
          content: Text(message, style: TextStyle(color: dialogTextColor)),
          actions: <Widget>[
            TextButton(
              child: Text('OK', style: TextStyle(color: primaryColor)),
              onPressed: onOkPressed ?? () => Navigator.of(context).pop(),
            ),
          ],
        );
      },
    );
  }

  void _handleChangePassword() {
    String newPassword = _newPasswordController.text.trim();
    String confirmPassword = _confirmPasswordController.text.trim();

    // Basic validation: Check if fields are empty
    if (newPassword.isEmpty || confirmPassword.isEmpty) {
      _showMessageBox(
        context,
        'Input Required',
        'Please enter both new and confirm passwords.',
      );
      return;
    }

    // Basic validation: Check password length
    if (newPassword.length < 6) { // Example: minimum 6 characters
      _showMessageBox(
        context,
        'Password Too Short',
        'New password must be at least 6 characters long.',
      );
      return;
    }

    // Check if passwords match
    if (newPassword != confirmPassword) {
      _showMessageBox(
        context,
        'Password Mismatch',
        'The new password and confirm password do not match.',
      );
    } else {
      // In a real application, you would perform the actual password change
      // (e.g., call an API, update Firebase, etc.) here.
      // For this example, we'll just simulate success and navigate.

      _showMessageBox(
        context,
        'Password Changed',
        'Your password has been successfully updated!',
        onOkPressed: () {
          Navigator.pop(context); // Pop the success dialog
          // Navigate to HomePage on successful password change
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const HomePage()),
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Access theme properties from ThemeProvider
    final themeProvider = Provider.of<ThemeProvider>(context);
    final Color bgColor = themeProvider.isDarkMode ? const Color(0xFF1A1A1A) : const Color(0xFF77BEF0); // Background for this specific page
    final Color textColor = themeProvider.isDarkMode ? Colors.white : Colors.black87;
    final Color primaryColor = themeProvider.primaryColor;
    final Color cardColor = themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;


    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: primaryColor, // AppBar uses primary color
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            width: 360,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardColor, // Card uses card color
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: themeProvider.isDarkMode ? Colors.black54 : Colors.black26,
                  blurRadius: 12,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(height: 12),
                // Ensure you have 'assets/images/logo.png' in your project
                // Note: Image.asset does not change color based on theme, it's a static image
                Image.asset('assets/images/logo.png', height: 75),
                const SizedBox(height: 12),
                Text(
                  'Change Password',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: textColor),
                ),
                const SizedBox(height: 12),
                Text(
                  'Enter your new password below.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: textColor.withOpacity(0.7)),
                ),
                const SizedBox(height: 24),
                TextField(
                  controller: _newPasswordController,
                  obscureText: !_isNewPasswordVisible, // Toggle visibility
                  style: TextStyle(color: textColor), // Text color in input field
                  decoration: InputDecoration(
                    hintText: 'New Password',
                    hintStyle: TextStyle(color: textColor.withOpacity(0.5)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: textColor.withOpacity(0.5)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: textColor.withOpacity(0.5)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: primaryColor, width: 2),
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _isNewPasswordVisible ? Icons.visibility : Icons.visibility_off,
                        color: textColor.withOpacity(0.7),
                      ),
                      onPressed: () {
                        setState(() {
                          _isNewPasswordVisible = !_isNewPasswordVisible;
                        });
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _confirmPasswordController,
                  obscureText: !_isConfirmPasswordVisible, // Toggle visibility
                  style: TextStyle(color: textColor), // Text color in input field
                  decoration: InputDecoration(
                    hintText: 'Confirm Password',
                    hintStyle: TextStyle(color: textColor.withOpacity(0.5)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: textColor.withOpacity(0.5)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: textColor.withOpacity(0.5)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: primaryColor, width: 2),
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _isConfirmPasswordVisible ? Icons.visibility : Icons.visibility_off,
                        color: textColor.withOpacity(0.7),
                      ),
                      onPressed: () {
                        setState(() {
                          _isConfirmPasswordVisible = !_isConfirmPasswordVisible;
                        });
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _handleChangePassword,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primaryColor, // Button uses primary color
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      foregroundColor: themeProvider.getOnPrimaryColorText(), // Text color on button
                    ),
                    child: const Text('Submit'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
