import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'user_data.dart'; // Ensure this path is correct for your UserInfo and UserDataProvider
import 'theme_provider.dart'; // Import the new ThemeProvider

class UserPage extends StatefulWidget {
  const UserPage({super.key}); // No longer needs isDarkMode as a parameter

  @override
  State<UserPage> createState() => _UserPageState();
}

class _UserPageState extends State<UserPage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _dobController = TextEditingController();
  final TextEditingController _bioController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Initialize controllers with current user data from the provider
    // Listen: false is used here because we are only reading the initial value,
    // not reacting to subsequent changes within initState.
    final userData = Provider.of<UserDataProvider>(context, listen: false).userInfo;
    _nameController.text = userData.name;
    _emailController.text = userData.email;
    _phoneController.text = userData.phone;
    _locationController.text = userData.location;
    _dobController.text = userData.dob;
    _bioController.text = userData.bio;
  }

  @override
  void dispose() {
    // Dispose controllers to prevent memory leaks
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _locationController.dispose();
    _dobController.dispose();
    _bioController.dispose();
    super.dispose();
  }

  void _saveProfile() {
    // Access the UserDataProvider to update user information
    // Listen: false is used here because we are only calling a method, not rebuilding
    Provider.of<UserDataProvider>(context, listen: false).updateUserInfo(
      name: _nameController.text.trim(),
      email: _emailController.text.trim(),
      phone: _phoneController.text.trim(),
      location: _locationController.text.trim(),
      dob: _dobController.text.trim(),
      bio: _bioController.text.trim(),
    );

    // Show a success message
    _showMessageBox(context, 'Profile Updated', 'Your profile has been saved successfully!');
  }

  // Helper method to show AlertDialogs (similar to showMessageBox in main.dart)
  void _showMessageBox(BuildContext context, String title, String message) {
    final themeProvider = Provider.of<ThemeProvider>(context, listen: false);
    final bool isDarkMode = themeProvider.isDarkMode;
    final Color dialogBgColor = isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;
    final Color dialogTextColor = isDarkMode ? Colors.white : Colors.black87;
    final Color primaryColor = themeProvider.primaryColor;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: dialogBgColor,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
          title: Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: dialogTextColor)),
          content: Text(message, style: TextStyle(color: dialogTextColor)),
          actions: <Widget>[
            TextButton(
              child: Text('OK', style: TextStyle(color: primaryColor)),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    // Access theme properties from ThemeProvider
    final themeProvider = Provider.of<ThemeProvider>(context);
    final Color bgColor = themeProvider.isDarkMode ? const Color(0xFF1A1A1A) : const Color(0xFFF0F2F5);
    final Color textColor = themeProvider.isDarkMode ? Colors.white : Colors.black87;
    final Color subtitleColor = themeProvider.isDarkMode ? Colors.grey[400]! : Colors.black54;
    final Color cardColor = themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;
    final Color primaryColor = themeProvider.primaryColor;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.white,
          size: 28,
        ),
        title: const Text(
          'User Profile',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontSize: 22,
          ),
        ),
        backgroundColor: primaryColor,
        elevation: 10,
        shadowColor: Colors.black87,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(6),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Stack(
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundColor: primaryColor.withOpacity(0.2),
                    child: Icon(Icons.person, size: 80, color: primaryColor),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: GestureDetector(
                      onTap: () {
                        // Implement image picking functionality here
                        _showMessageBox(context, 'Feature Coming Soon', 'Image upload is not yet implemented.');
                      },
                      child: CircleAvatar(
                        radius: 20,
                        backgroundColor: primaryColor,
                        child: const Icon(Icons.camera_alt, color: Colors.white, size: 20),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Personal Information',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: textColor,
              ),
            ),
            const SizedBox(height: 16),
            _buildEditableField(
              context,
              'Name',
              _nameController,
              Icons.person,
              textColor,
              subtitleColor,
              cardColor,
              primaryColor,
            ),
            _buildEditableField(
              context,
              'Email',
              _emailController,
              Icons.email,
              textColor,
              subtitleColor,
              cardColor,
              primaryColor,
              keyboardType: TextInputType.emailAddress,
            ),
            _buildEditableField(
              context,
              'Phone',
              _phoneController,
              Icons.phone,
              textColor,
              subtitleColor,
              cardColor,
              primaryColor,
              keyboardType: TextInputType.phone,
            ),
            _buildEditableField(
              context,
              'Location',
              _locationController,
              Icons.location_on,
              textColor,
              subtitleColor,
              cardColor,
              primaryColor,
            ),
            _buildEditableField(
              context,
              'Date of Birth',
              _dobController,
              Icons.calendar_today,
              textColor,
              subtitleColor,
              cardColor,
              primaryColor,
              readOnly: true, // Make DOB read-only for date picker
              onTap: () async {
                DateTime? pickedDate = await showDatePicker(
                  context: context,
                  initialDate: DateTime.tryParse(_dobController.text) ?? DateTime.now(),
                  firstDate: DateTime(1900),
                  lastDate: DateTime.now(),
                  builder: (context, child) {
                    return Theme(
                      data: Theme.of(context).copyWith(
                        colorScheme: ColorScheme.light(
                          primary: primaryColor, // header background color
                          onPrimary: themeProvider.getOnPrimaryColorText(), // header text color
                          onSurface: textColor, // body text color
                        ),
                        textButtonTheme: TextButtonThemeData(
                          style: TextButton.styleFrom(
                            foregroundColor: primaryColor, // button text color
                          ),
                        ),
                      ),
                      child: child!,
                    );
                  },
                );
                if (pickedDate != null) {
                  setState(() {
                    _dobController.text = "${pickedDate.month}/${pickedDate.day}/${pickedDate.year}";
                  });
                }
              },
            ),
            _buildEditableField(
              context,
              'Bio',
              _bioController,
              Icons.info_outline,
              textColor,
              subtitleColor,
              cardColor,
              primaryColor,
              maxLines: 3,
            ),
            const SizedBox(height: 30),
            Center(
              child: ElevatedButton.icon(
                onPressed: _saveProfile,
                icon: const Icon(Icons.save),
                label: const Text('Save Profile'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  foregroundColor: themeProvider.getOnPrimaryColorText(),
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 5,
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildEditableField(
    BuildContext context,
    String label,
    TextEditingController controller,
    IconData icon,
    Color textColor,
    Color subtitleColor,
    Color cardColor,
    Color primaryColor, {
    TextInputType keyboardType = TextInputType.text,
    bool readOnly = false,
    VoidCallback? onTap,
    int maxLines = 1,
  }) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final Color inputFillColor = themeProvider.isDarkMode ? const Color(0xFF3A3A3A) : Colors.grey[100]!;
    final Color inputBorderColor = themeProvider.isDarkMode ? Colors.grey[600]! : Colors.grey[400]!;

    return Card(
      color: cardColor,
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: subtitleColor,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: controller,
              keyboardType: keyboardType,
              readOnly: readOnly,
              onTap: onTap,
              maxLines: maxLines,
              style: TextStyle(color: textColor, fontSize: 16),
              decoration: InputDecoration(
                prefixIcon: Icon(icon, color: primaryColor),
                filled: true,
                fillColor: inputFillColor,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: inputBorderColor),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: inputBorderColor),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: primaryColor, width: 2),
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
