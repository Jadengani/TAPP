import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'userpage.dart';
import 'notification_page.dart';
import 'helppage.dart';
import 'loginpage.dart';
import 'user_data.dart';
import 'theme_provider.dart';
import 'changepassword.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final Color bgColor = themeProvider.isDarkMode ? const Color(0xFF1A1A1A) : const Color(0xFFF0F2F5);
    final Color textColor = themeProvider.isDarkMode ? Colors.white : Colors.black87;
    final Color subtitleColor = themeProvider.isDarkMode ? Colors.grey[400]! : Colors.black54;
    final Color cardColor = themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;
    final Color primaryColor = themeProvider.primaryColor;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        iconTheme: const IconThemeData(
          color: Colors.white,
          size: 28,
        ),
        title: const Text(
          'Settings',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontSize: 22,
          ),
        ),
        backgroundColor: primaryColor,
        elevation: 10,
        shadowColor: Colors.black87,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(6),
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          _buildSettingsCategory(
            context: context,
            title: 'Account',
            textColor: textColor,
            children: [
              _buildSettingsTile(
                context: context,
                title: 'User Profile',
                subtitle: 'Manage your personal information',
                icon: Icons.person,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const UserPage(),
                    ),
                  );
                },
                textColor: textColor,
                subtitleColor: subtitleColor,
                cardColor: cardColor,
                primaryColor: primaryColor,
              ),
              _buildSettingsTile(
                context: context,
                title: 'Change Password',
                subtitle: 'Update your account password',
                icon: Icons.lock,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const ChangePasswordPage()),
                  );
                },
                textColor: textColor,
                subtitleColor: subtitleColor,
                cardColor: cardColor,
                primaryColor: primaryColor,
              ),
            ],
          ),
          const SizedBox(height: 20),
          _buildSettingsCategory(
            context: context,
            title: 'App Preferences',
            textColor: textColor,
            children: [
              _buildSettingsTile(
                context: context,
                title: 'Notifications',
                subtitle: 'View your app notifications',
                icon: Icons.notifications,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const NotificationPage()),
                  );
                },
                textColor: textColor,
                subtitleColor: subtitleColor,
                cardColor: cardColor,
                primaryColor: primaryColor,
              ),
              _buildThemeToggleTile(
                context: context,
                title: 'Dark Mode',
                subtitle: themeProvider.isDarkMode ? 'On' : 'Off',
                icon: themeProvider.isDarkMode ? Icons.nightlight_round : Icons.wb_sunny,
                value: themeProvider.isDarkMode,
                onChanged: (value) {
                  themeProvider.toggleTheme();
                },
                textColor: textColor,
                subtitleColor: subtitleColor,
                cardColor: cardColor,
                primaryColor: primaryColor,
              ),
              _buildColorPickerTile(
                context: context,
                title: 'App Color Theme',
                subtitle: 'Choose your primary app color',
                icon: Icons.color_lens,
                textColor: textColor,
                subtitleColor: subtitleColor,
                cardColor: cardColor,
                primaryColor: primaryColor,
                themeProvider: themeProvider,
              ),
            ],
          ),
          const SizedBox(height: 20),
          _buildSettingsCategory(
            context: context,
            title: 'Help & Support',
            textColor: textColor,
            children: [
              _buildSettingsTile(
                context: context,
                title: 'Help',
                subtitle: 'Find answers to common questions',
                icon: Icons.help_outline,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const HelpPage()),
                  );
                },
                textColor: textColor,
                subtitleColor: subtitleColor,
                cardColor: cardColor,
                primaryColor: primaryColor,
              ),
              _buildSettingsTile(
                context: context,
                title: 'About',
                subtitle: 'Information about the app',
                icon: Icons.info_outline,
                onTap: () {
                  showAboutDialog(
                    context: context,
                    applicationName: 'Tapp Home Automation',
                    applicationVersion: '1.0.0',
                    applicationLegalese: '© 2024 Tapp. All rights reserved.',
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 15.0),
                        child: Text(
                          'A smart home control application designed for convenience.',
                          style: TextStyle(color: textColor),
                        ),
                      ),
                    ],
                  );
                },
                textColor: textColor,
                subtitleColor: subtitleColor,
                cardColor: cardColor,
                primaryColor: primaryColor,
              ),
            ],
          ),
          const SizedBox(height: 30),
          _buildLogoutButton(
            context: context,
            textColor: textColor,
            primaryColor: Colors.redAccent,
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildSettingsCategory({
    required BuildContext context,
    required String title,
    required Color textColor,
    required List<Widget> children,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 10.0),
          child: Text(
            title,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: textColor.withOpacity(0.8),
            ),
          ),
        ),
        Column(children: children),
      ],
    );
  }

  Widget _buildSettingsTile({
    required BuildContext context,
    required String title,
    String? subtitle,
    required IconData icon,
    VoidCallback? onTap,
    required Color textColor,
    required Color subtitleColor,
    required Color cardColor,
    required Color primaryColor,
  }) {
    return Card(
      color: cardColor,
      margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 0.0),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        leading: Icon(icon, color: primaryColor, size: 28),
        title: Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 17,
            color: textColor,
          ),
        ),
        subtitle: subtitle != null
            ? Text(
                subtitle,
                style: TextStyle(fontSize: 13, color: subtitleColor),
              )
            : null,
        trailing: Icon(Icons.arrow_forward_ios, color: subtitleColor, size: 18),
        onTap: onTap,
      ),
    );
  }

  Widget _buildThemeToggleTile({
    required BuildContext context,
    required String title,
    String? subtitle,
    required IconData icon,
    required bool value,
    required ValueChanged<bool> onChanged,
    required Color textColor,
    required Color subtitleColor,
    required Color cardColor,
    required Color primaryColor,
  }) {
    return Card(
      color: cardColor,
      margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 0.0),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: SwitchListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        secondary: Icon(icon, color: primaryColor, size: 28),
        title: Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 17,
            color: textColor,
          ),
        ),
        subtitle: subtitle != null
            ? Text(
                subtitle,
                style: TextStyle(fontSize: 13, color: subtitleColor),
              )
            : null,
        value: value,
        onChanged: onChanged,
        activeColor: primaryColor,
        inactiveThumbColor: subtitleColor,
        inactiveTrackColor: subtitleColor.withOpacity(0.3),
      ),
    );
  }

  Widget _buildColorPickerTile({
    required BuildContext context,
    required String title,
    String? subtitle,
    required IconData icon,
    required Color textColor,
    required Color subtitleColor,
    required Color cardColor,
    required Color primaryColor,
    required ThemeProvider themeProvider,
  }) {
    return Card(
      color: cardColor,
      margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 0.0),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        leading: Icon(icon, color: primaryColor, size: 28),
        title: Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 17,
            color: textColor,
          ),
        ),
        subtitle: subtitle != null
            ? Text(
                subtitle,
                style: TextStyle(fontSize: 13, color: subtitleColor),
              )
            : null,
        trailing: Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            color: primaryColor,
            shape: BoxShape.circle,
            border: Border.all(color: subtitleColor, width: 1.5),
          ),
        ),
        onTap: () {
          showDialog(
            context: context,
            builder: (ctx) {
              return AlertDialog(
                backgroundColor: themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white,
                title: Text('Select Primary Color', style: TextStyle(color: textColor)),
                content: SingleChildScrollView(
                  child: Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: themeProvider.pastelColors.map((color) {
                      return GestureDetector(
                        onTap: () {
                          themeProvider.setPrimaryColor(color);
                          Navigator.pop(ctx);
                        },
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: color,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: themeProvider.primaryColor == color ? textColor : Colors.transparent,
                              width: 3,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.2),
                                blurRadius: 5,
                                offset: const Offset(2, 2),
                              ),
                            ],
                          ),
                          child: themeProvider.primaryColor == color
                              ? Icon(Icons.check, color: themeProvider.getOnPrimaryColorText())
                              : null,
                        ),
                      );
                    }).toList(),
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: Text('Cancel', style: TextStyle(color: primaryColor)),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildLogoutButton({
    required BuildContext context,
    required Color textColor,
    required Color primaryColor,
  }) {
    final themeProvider = Provider.of<ThemeProvider>(context, listen: false);

    return ElevatedButton.icon(
      icon: const Icon(Icons.logout),
      label: const Text('Log Out'),
      onPressed: () {
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            backgroundColor: themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white,
            title: Text("Log Out?", style: TextStyle(color: textColor)),
            content: Text("Are you sure you want to log out?", style: TextStyle(color: textColor.withOpacity(0.8))),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text("Cancel", style: TextStyle(color: primaryColor)),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  Provider.of<UserDataProvider>(context, listen: false).clearUserInfo();
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => const LoginPage()),
                    (Route<dynamic> route) => false,
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  foregroundColor: Colors.white,
                ),
                child: const Text("Log Out"),
              ),
            ],
          ),
        );
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        elevation: 5,
      ),
    );
  }
}
