// lib/homepage.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'remotepage.dart';
import 'loginpage.dart';
import 'userpage.dart'; // Corrected import: 'userpage.dart'
import 'settingspage.dart';
import 'notification_page.dart';
import 'helppage.dart';
import 'notification_memory.dart'; // Corrected filename
import 'user_data.dart'; // Ensure this import is correct for UserInfo and UserDataProvider
import 'theme_provider.dart'; // Import the new ThemeProvider

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Map<String, String> roomImages = {
    "Master’s Bedroom": "assets/images/mb.jpg",
    "CR": "assets/images/cr.jpg",
    "Terrace": "assets/images/t.jpg",
    "Kitchen": "assets/images/k.jpg",
    "Attic": "assets/images/a.jpg",
    "Basement": "assets/images/bm.jpg",
    "Bedroom": "assets/images/br.jpg",
    "Dirty Kitchen": "assets/images/dk.jpg",
    "Dining Room": "assets/images/dr.jpg",
    "Garage": "assets/images/g.jpg",
    "Laundry": "assets/images/l.jpg",
    "Living Room": "assets/images/lv.jpg",
    "Nursery Room": "assets/images/nr.jpg",
    "Room": "assets/images/r.jpg",
    "Study Area": "assets/images/sa.jpg",
  };

  final Map<String, String> allRooms = {
    "Kitchen": "assets/images/k.jpg",
    "Attic": "assets/images/a.jpg",
    "Basement": "assets/images/bm.jpg",
    "Bedroom": "assets/images/br.jpg",
    "CR": "assets/images/cr.jpg",
    "Dirty Kitchen": "assets/images/dk.jpg",
    "Dining Room": "assets/images/dr.jpg",
    "Garage": "assets/images/g.jpg",
    "Laundry": "assets/images/l.jpg",
    "Living Room": "assets/images/lv.jpg",
    "Master’s Bedroom": "assets/images/mb.jpg",
    "Nursery Room": "assets/images/nr.jpg",
    "Room": "assets/images/r.jpg",
    "Study Area": "assets/images/sa.jpg",
    "Terrace": "assets/images/t.jpg",
  };

  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    NotificationMemory.loadNotifications();
  }

  void _addRoom() {
    String? selectedRoom;
    final fixedRoomOptions = allRooms.keys.toList();

    showDialog(
      context: context,
      builder: (ctx) {
        final themeProvider = Provider.of<ThemeProvider>(ctx);
        final dialogBgColor = themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;
        final dialogTextColor = themeProvider.isDarkMode ? Colors.white : Colors.black87;
        final dialogHintColor = themeProvider.isDarkMode ? Colors.grey[500] : Colors.black54;

        return AlertDialog(
          backgroundColor: dialogBgColor,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          elevation: 15,
          title: Text("Add Room", style: TextStyle(color: dialogTextColor, fontWeight: FontWeight.bold)),
          content: SizedBox(
            width: double.maxFinite,
            child: DropdownButtonFormField<String>(
              isExpanded: true,
              decoration: InputDecoration(
                labelText: "Select Room",
                labelStyle: TextStyle(color: dialogHintColor),
                border: const OutlineInputBorder(),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: dialogHintColor!),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: themeProvider.primaryColor, width: 2),
                ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              ),
              dropdownColor: dialogBgColor,
              style: TextStyle(color: dialogTextColor),
              menuMaxHeight: 240.0,
              items: fixedRoomOptions.map((room) {
                return DropdownMenuItem<String>(
                  value: room,
                  child: Text(room, style: TextStyle(color: dialogTextColor)),
                );
              }).toList(),
              onChanged: (value) => selectedRoom = value,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text("Cancel", style: TextStyle(color: themeProvider.primaryColor)),
            ),
            ElevatedButton(
              onPressed: () {
                if (selectedRoom != null && selectedRoom!.trim().isNotEmpty) {
                  String baseName = selectedRoom!.trim();
                  String newRoomName = baseName;
                  int count = 1;

                  while (roomImages.containsKey(newRoomName)) {
                    newRoomName = "$baseName $count";
                    count++;
                  }

                  setState(() {
                    roomImages[newRoomName] = allRooms[baseName] ?? "assets/images/default.jpg";
                    NotificationMemory.addNotification({
                      'type': 'added',
                      'title': 'Room Added',
                      'subtitle': '$newRoomName was added',
                      'timestamp': DateTime.now(),
                    });
                  });
                }
                Navigator.pop(ctx);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: themeProvider.primaryColor,
                foregroundColor: themeProvider.getOnPrimaryColorText(),
              ),
              child: const Text("Add"),
            ),
          ],
        );
      },
    );
  }

  void _deleteRoom() {
    String? selectedRoom;

    showDialog(
      context: context,
      builder: (ctx) {
        final themeProvider = Provider.of<ThemeProvider>(ctx);
        final dialogBgColor = themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white;
        final dialogTextColor = themeProvider.isDarkMode ? Colors.white : Colors.black87;
        final dialogHintColor = themeProvider.isDarkMode ? Colors.grey[500] : Colors.black54;

        return AlertDialog(
          backgroundColor: dialogBgColor,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          elevation: 15,
          title: Text("Delete Room", style: TextStyle(color: dialogTextColor, fontWeight: FontWeight.bold)),
          content: SizedBox(
            width: double.maxFinite,
            child: DropdownButtonFormField<String>(
              isExpanded: true,
              decoration: InputDecoration(
                labelText: "Select Room to Delete",
                labelStyle: TextStyle(color: dialogHintColor),
                border: const OutlineInputBorder(),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: dialogHintColor!),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: themeProvider.primaryColor, width: 2),
                ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              ),
              dropdownColor: dialogBgColor,
              style: TextStyle(color: dialogTextColor),
              menuMaxHeight: 240.0,
              items: roomImages.keys.map((room) {
                return DropdownMenuItem<String>(
                  value: room,
                  child: Text(room, style: TextStyle(color: dialogTextColor)),
                );
              }).toList(),
              onChanged: (value) => selectedRoom = value,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text("Cancel", style: TextStyle(color: themeProvider.primaryColor)),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(ctx);
                if (selectedRoom != null && roomImages.containsKey(selectedRoom)) {
                  setState(() {
                    roomImages.remove(selectedRoom);
                    NotificationMemory.addNotification({
                      'type': 'deleted',
                      'title': 'Room Deleted',
                      'subtitle': '$selectedRoom was deleted',
                      'timestamp': DateTime.now(),
                    });
                  });
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text("Delete"),
            ),
          ],
        );
      },
    );
  }

  void _logout() {
    // Clear user data before logging out
    // This assumes user_data.dart has the clearUserInfo method
    Provider.of<UserDataProvider>(context, listen: false).clearUserInfo();
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginPage()));
  }

  void _openUserPage() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const UserPage(), // Corrected constructor call
      ),
    );
  }

  void _onBottomNavTap(int index) {
    if (index == 0) {
      setState(() {});
    } else if (index == 1) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const NotificationPage()), // Corrected constructor call
      );
    } else if (index == 2) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => const SettingsPage(),
        ),
      );
    }

    setState(() {
      _selectedIndex = index;
    });
  }

  IconData _getRoomIcon(String roomName) {
    roomName = roomName.toLowerCase();
    if (roomName.contains("bedroom")) return Icons.bed;
    if (roomName.contains("kitchen")) return Icons.kitchen;
    if (roomName.contains("bathroom") || roomName.contains("cr")) return Icons.bathtub;
    if (roomName.contains("living")) return Icons.tv;
    if (roomName.contains("dining")) return Icons.restaurant;
    if (roomName.contains("garage")) return Icons.garage;
    if (roomName.contains("laundry")) return Icons.local_laundry_service;
    if (roomName.contains("attic")) return Icons.roofing;
    if (roomName.contains("terrace") || roomName.contains("balcony")) return Icons.park;
    if (roomName.contains("basement")) return Icons.foundation;
    if (roomName.contains("study") || roomName.contains("office")) return Icons.menu_book;
    if (roomName.contains("nursery")) return Icons.child_friendly;
    return Icons.home;
  }

  Widget _buildDrawerListTile(String title, IconData icon, int? index, ThemeProvider themeProvider) {
    final bool isSelected = index != null ? _selectedIndex == index : false;

    return ListTile(
      leading: Icon(icon, color: Colors.white),
      title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500, fontSize: 16)),
      onTap: () {
        Navigator.pop(context);
        if (index != null) {
          _onBottomNavTap(index);
        } else if (title == 'Help') {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const HelpPage()));
        }
      },
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      hoverColor: Colors.white.withOpacity(0.1),
      splashColor: Colors.white.withOpacity(0.2),
      selected: isSelected,
      selectedTileColor: Colors.white.withOpacity(0.1),
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final Color primaryColor = themeProvider.primaryColor;
    final Color bgColor = themeProvider.isDarkMode ? const Color(0xFF1A1A1A) : const Color(0xFFF0F2F5);
    final Color textColor = themeProvider.isDarkMode ? Colors.white : Colors.black87;
    final Color? subtitleColor = themeProvider.isDarkMode ? Colors.grey[400] : Colors.black54;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: primaryColor,
        elevation: 10,
        shadowColor: Colors.black87,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(6)),
        ),
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: Colors.white),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        title: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset('assets/images/logo2.png', height: 32, width: 32, fit: BoxFit.contain),
            ),
            const SizedBox(width: 8),
            const Text(
              "Tapp",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 24,
                color: Colors.white,
                shadows: [
                  Shadow(
                    color: Colors.black38,
                    blurRadius: 2,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(themeProvider.isDarkMode ? Icons.wb_sunny_rounded : Icons.nightlight_round, color: Colors.white),
            onPressed: () {
              themeProvider.toggleTheme();
            },
            tooltip: themeProvider.isDarkMode ? "Light Mode" : "Dark Mode",
          )
        ],
      ),
      drawer: Drawer(
        backgroundColor: primaryColor,
        child: Column(
          children: [
            GestureDetector(
              onTap: _openUserPage,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
                decoration: BoxDecoration(
                  border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.2), width: 1.0)),
                ),
                child: Consumer<UserDataProvider>(
                  builder: (context, userDataProvider, child) {
                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const Icon(Icons.account_circle, size: 72, color: Colors.white),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Text(
                            userDataProvider.userInfo.name,
                            style: const TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.w800),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ),
            _buildDrawerListTile('Home', Icons.home_rounded, 0, themeProvider),
            _buildDrawerListTile('Notification', Icons.notifications_rounded, 1, themeProvider),
            _buildDrawerListTile('Settings', Icons.settings_rounded, 2, themeProvider),
            _buildDrawerListTile('Help', Icons.help_rounded, null, themeProvider),
            const Spacer(),
            ListTile(
              leading: const Icon(Icons.logout_rounded, color: Colors.white),
              title: const Text('Log Out', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              onTap: _logout,
              contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              hoverColor: Colors.white.withOpacity(0.1),
              splashColor: Colors.white.withOpacity(0.2),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: MediaQuery.of(context).size.height * 0.03),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Consumer<UserDataProvider>(
                            builder: (context, userDataProvider, child) {
                              return Text(
                                "Hi ${userDataProvider.userInfo.name}!",
                                style: TextStyle(
                                  fontSize: 40,
                                  fontWeight: FontWeight.bold,
                                  color: textColor,
                                  shadows: [
                                    Shadow(
                                      color: themeProvider.isDarkMode ? Colors.black.withOpacity(0.4) : Colors.transparent,
                                      blurRadius: 2,
                                      offset: const Offset(1, 1),
                                    ),
                                  ],
                                ),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              );
                            },
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Wherever you are, your home is in your hands.",
                            style: TextStyle(fontSize: 15, color: subtitleColor, fontWeight: FontWeight.w400),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 16),
                    GestureDetector(
                      onTap: _openUserPage,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: primaryColor,
                          boxShadow: [
                            BoxShadow(
                              color: primaryColor.withOpacity(0.6),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: const Icon(Icons.person_rounded, size: 56, color: Colors.white),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                Row(
                  children: [
                    Text("Room:", style: TextStyle(fontWeight: FontWeight.bold, color: textColor)),
                    const SizedBox(width: 10),
                    DropdownButton<String>(
                      hint: Text("Select Action", style: TextStyle(color: subtitleColor)),
                      value: null,
                      icon: Icon(Icons.arrow_drop_down, color: textColor),
                      underline: Container(height: 1, color: textColor.withOpacity(0.5)),
                      dropdownColor: themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white,
                      style: TextStyle(color: textColor),
                      items: const [
                        DropdownMenuItem(value: "Add", child: Text("Add")),
                        DropdownMenuItem(value: "Delete", child: Text("Delete")),
                      ].map((item) => DropdownMenuItem<String>(
                                value: item.value,
                                child: Text(item.value!, style: TextStyle(color: textColor)),
                              )).toList(),
                      onChanged: (value) {
                        if (value == "Add") _addRoom();
                        if (value == "Delete") _deleteRoom();
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: roomImages.isEmpty
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.home_work_outlined, size: 80, color: subtitleColor!.withOpacity(0.5)),
                        const SizedBox(height: 20),
                        Text("No rooms added yet.", style: TextStyle(color: subtitleColor, fontSize: 18, fontStyle: FontStyle.italic)),
                        const SizedBox(height: 5),
                        Text("Add your first room above!", style: TextStyle(color: subtitleColor, fontSize: 14)),
                        const SizedBox(height: 20),
                      ],
                    )
                  : GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 16,
                        crossAxisSpacing: 16,
                        childAspectRatio: 3 / 2,
                      ),
                      itemCount: roomImages.length,
                      itemBuilder: (context, index) {
                        final entry = roomImages.entries.elementAt(index);
                        return GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => RemotePage(roomName: entry.key),
                              ),
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: themeProvider.isDarkMode ? const Color(0xFF2C2C2C) : Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(
                                  color: themeProvider.isDarkMode ? Colors.black.withOpacity(0.5) : Colors.grey.withOpacity(0.3),
                                  blurRadius: 10,
                                  offset: const Offset(0, 5),
                                ),
                              ],
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(16),
                              child: Stack(
                                fit: StackFit.expand,
                                children: [
                                  Image.asset(entry.value, fit: BoxFit.cover),
                                  Container(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                        colors: [
                                          Colors.black.withOpacity(0.3),
                                          Colors.transparent,
                                          Colors.black.withOpacity(0.7),
                                        ],
                                        stops: const [0.0, 0.6, 1.0],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    top: 12,
                                    left: 12,
                                    child: Icon(_getRoomIcon(entry.key), color: Colors.white, size: 32),
                                  ),
                                  Positioned(
                                    bottom: 12,
                                    left: 12,
                                    right: 12,
                                    child: Text(
                                      entry.key,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 18,
                                        shadows: [
                                          Shadow(
                                            color: Colors.black54,
                                            blurRadius: 4,
                                            offset: Offset(1, 1),
                                          ),
                                        ],
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        backgroundColor: primaryColor,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white70,
        onTap: _onBottomNavTap,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.notifications_rounded), label: "Notifications"),
          BottomNavigationBarItem(icon: Icon(Icons.settings_rounded), label: "Settings"),
        ],
      ),
    );
  }
}
